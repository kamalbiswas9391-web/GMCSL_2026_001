import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Award,
  BadgeCheck,
  Building2,
  Calendar,
  CreditCard,
  FileCheck2,
  Landmark,
  PiggyBank,
  QrCode,
  ShieldAlert,
  Users,
  Wallet,
} from 'lucide-react';
import { AppShell, type NavTabId } from '../components/AppShell';
import { DashboardCharts } from '../components/DashboardCharts';
import { StatusLabel } from '../components/UiPrimitives';
import { useApp } from '../context/AppContext';
import {
  CashBookView,
  LoanRegisterView,
  MemberRegisterView,
  SavingRegisterView,
  ShareRegisterView,
} from '../modules/FinancialRegisters';
import {
  AttendanceRegisterView,
  LoanApplicationView,
  MeetingsView,
  OnlinePaymentView,
} from '../modules/OperationsAndWorkflows';
import {
  IdAndCertificateHub,
  NoticeBoardView,
  NotificationsCenterView,
  ReportsCenterView,
} from '../modules/DocumentsAndReportsModule';
import {
  PermissionSwitchboardView,
  SocietySettingsView,
  UsersAndPinManagerView,
} from '../modules/SystemGovernanceViews';
import {
  AuditLogView,
  BackupAndRestoreView,
  GoogleSheetsIntegrationView,
  OfflineSyncAndConflictView,
  SecurityAndCredentialsView,
} from '../modules/SystemInfraViews';

const formatCurrency = (val: number, symbol = '₹') =>
  `${symbol}${Number(val || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const KpiCard: React.FC<{
  label: string;
  value: string | number;
  sub?: string;
  accent?: string;
}> = ({ label, value, sub, accent = 'text-[#142D4E] dark:text-white' }) => (
  <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between">
    <p className="text-xs font-medium text-[#667085] dark:text-slate-400">{label}</p>
    <p className={`mt-2 text-xl sm:text-2xl font-bold font-mono-tabular ${accent}`}>{value}</p>
    {sub && <p className="mt-1 text-[11px] text-[#667085] dark:text-slate-400 truncate">{sub}</p>}
  </div>
);

const LiveSyncHeaderBadge: React.FC<{ isLive: boolean; syncedAt?: string | null }> = ({ isLive, syncedAt }) => {
  const { tr } = useApp();
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-xs">
      <div className="flex items-center gap-2 font-semibold">
        <span className={isLive ? 'text-emerald-700 dark:text-emerald-400' : 'text-amber-700 dark:text-amber-400'}>
          {isLive ? tr('liveDataBadge') : tr('cachedDataBadge')}
        </span>
      </div>
      <span className="text-[#667085] dark:text-slate-400 font-mono-tabular">
        {tr('lastSynchronized')}: {syncedAt ? new Date(syncedAt).toLocaleString() : '—'}
      </span>
    </div>
  );
};

// ==========================================
// SYSTEM DASHBOARD OVERVIEW (19 KPIs)
// ==========================================
const SystemOverview: React.FC<{ onNavigate: (t: NavTabId) => void }> = ({ onNavigate }) => {
  const { snapshot, tr, isOnline } = useApp();
  if (!snapshot) return null;
  const st = snapshot.stats;
  const sym = snapshot.settings?.currencySymbol || '₹';

  return (
    <div className="space-y-6">
      <LiveSyncHeaderBadge isLive={isOnline && st.isLive} syncedAt={snapshot.syncedAt} />

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        <KpiCard label={tr('totalMembers')} value={st.totalMembers} />
        <KpiCard label={tr('activeMembers')} value={st.activeMembers} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('inactiveMembers')} value={st.inactiveMembers} accent="text-slate-600 dark:text-slate-300" />
        <KpiCard label={tr('monthlySavings')} value={formatCurrency(st.totalMonthlySavings, sym)} />
        <KpiCard label={tr('totalSavings')} value={formatCurrency(st.totalSavings, sym)} accent="text-[#087443] dark:text-emerald-400" />
        <KpiCard label={tr('totalShares')} value={st.totalShares} />
        <KpiCard label={tr('totalShareValue')} value={formatCurrency(st.totalShareValue, sym)} />
        <KpiCard label={tr('totalLoanDisbursed')} value={formatCurrency(st.totalLoanDisbursed, sym)} />
        <KpiCard label={tr('totalLoanBalance')} value={formatCurrency(st.totalLoanBalance, sym)} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label={tr('totalLoanInterest')} value={formatCurrency(st.totalLoanInterest, sym)} />
        <KpiCard label={tr('totalLoanFine')} value={formatCurrency(st.totalLoanFine, sym)} />
        <KpiCard label={tr('activeLoans')} value={st.activeLoans} accent="text-[#087443] dark:text-emerald-400" />
        <KpiCard label={tr('closedLoans')} value={st.closedLoans} />
        <KpiCard label={tr('inactiveLoans')} value={st.inactiveLoans} />
        <KpiCard label={tr('bankBalance')} value={formatCurrency(st.totalBankBalance, sym)} accent="text-blue-700 dark:text-blue-400" />
        <KpiCard label={tr('cashBalance')} value={formatCurrency(st.totalCashBalance, sym)} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('pendingLoanApps')} value={st.pendingLoanApplications} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label={tr('pendingPayments')} value={st.pendingOnlinePayments} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label={tr('totalMeetings')} value={st.totalMeetings} />
      </div>

      {/* Quick Governance Shortcuts */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { tab: 'permissions' as NavTabId, label: tr('nav_permissions') },
          { tab: 'google_sheets' as NavTabId, label: tr('nav_google_sheets') },
          { tab: 'payment_verification' as NavTabId, label: tr('nav_payment_verification') },
          { tab: 'backup_restore' as NavTabId, label: tr('nav_backup_restore') },
        ].map((q) => (
          <button
            key={q.tab}
            onClick={() => onNavigate(q.tab)}
            className="flex items-center justify-between gap-2 px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-[#087443] text-xs font-semibold text-[#142D4E] dark:text-white transition-colors"
          >
            <span className="truncate">{q.label}</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#087443] shrink-0" />
          </button>
        ))}
      </div>

      <DashboardCharts snapshot={snapshot} mode="system" />
    </div>
  );
};

// ==========================================
// PRESIDENT DASHBOARD OVERVIEW
// ==========================================
const PresidentOverview: React.FC<{ onNavigate: (t: NavTabId) => void }> = ({ onNavigate }) => {
  const { snapshot, tr, isOnline } = useApp();
  if (!snapshot) return null;
  const st = snapshot.stats;
  const sym = snapshot.settings?.currencySymbol || '₹';

  return (
    <div className="space-y-6">
      <LiveSyncHeaderBadge isLive={isOnline && st.isLive} syncedAt={snapshot.syncedAt} />

      {(st.pendingLoanApplications > 0 || st.pendingOnlinePayments > 0) && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <div className="text-xs sm:text-sm">
              <p className="font-semibold text-amber-900 dark:text-amber-200">Executive Action Pending</p>
              <p className="text-amber-800 dark:text-amber-300">
                {st.pendingLoanApplications} loan application(s) awaiting decision · {st.pendingOnlinePayments} online payment(s) pending verification.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('loan_approval')}
            className="px-4 py-2 rounded-lg bg-[#087443] text-white text-xs font-semibold hover:bg-[#065c35] whitespace-nowrap"
          >
            Open Loan Approval Desk
          </button>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        <KpiCard label={tr('totalMembers')} value={st.totalMembers} />
        <KpiCard label={tr('activeMembers')} value={st.activeMembers} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('totalSavings')} value={formatCurrency(st.totalSavings, sym)} accent="text-[#087443] dark:text-emerald-400" />
        <KpiCard label={tr('totalShares')} value={st.totalShares} />
        <KpiCard label={tr('totalShareValue')} value={formatCurrency(st.totalShareValue, sym)} />
        <KpiCard label={tr('totalLoanDisbursed')} value={formatCurrency(st.totalLoanDisbursed, sym)} />
        <KpiCard label={tr('totalLoanBalance')} value={formatCurrency(st.totalLoanBalance, sym)} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label="Total Loan Repaid" value={formatCurrency(st.totalLoanRepaid, sym)} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('bankBalance')} value={formatCurrency(st.totalBankBalance, sym)} accent="text-blue-700 dark:text-blue-400" />
        <KpiCard label={tr('cashBalance')} value={formatCurrency(st.totalCashBalance, sym)} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('pendingLoanApps')} value={st.pendingLoanApplications} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label={tr('pendingPayments')} value={st.pendingOnlinePayments} accent="text-amber-700 dark:text-amber-400" />
      </div>

      <DashboardCharts snapshot={snapshot} mode="president" />
    </div>
  );
};

// ==========================================
// SECRETARY DASHBOARD OVERVIEW
// ==========================================
const SecretaryOverview: React.FC<{ onNavigate: (t: NavTabId) => void }> = ({ onNavigate }) => {
  const { snapshot, tr, isOnline } = useApp();
  if (!snapshot) return null;
  const st = snapshot.stats;
  const sym = snapshot.settings?.currencySymbol || '₹';
  const today = new Date().toISOString().slice(0, 10);
  const todaysAttendance = snapshot.attendance.filter((a) => a.date === today && a.attendanceStatus === 'Present').length;

  return (
    <div className="space-y-6">
      <LiveSyncHeaderBadge isLive={isOnline && st.isLive} syncedAt={snapshot.syncedAt} />

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        <KpiCard label={tr('totalMembers')} value={st.totalMembers} />
        <KpiCard label={tr('activeMembers')} value={st.activeMembers} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('monthlySavings')} value={formatCurrency(st.totalMonthlySavings, sym)} />
        <KpiCard label={tr('totalSavings')} value={formatCurrency(st.totalSavings, sym)} accent="text-[#087443] dark:text-emerald-400" />
        <KpiCard label={tr('totalShares')} value={st.totalShares} />
        <KpiCard label={tr('totalLoanDisbursed')} value={formatCurrency(st.totalLoanDisbursed, sym)} />
        <KpiCard label={tr('totalLoanBalance')} value={formatCurrency(st.totalLoanBalance, sym)} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label={tr('activeLoans')} value={st.activeLoans} />
        <KpiCard label={tr('bankBalance')} value={formatCurrency(st.totalBankBalance, sym)} accent="text-blue-700 dark:text-blue-400" />
        <KpiCard label={tr('cashBalance')} value={formatCurrency(st.totalCashBalance, sym)} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('pendingPayments')} value={st.pendingOnlinePayments} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label={tr('totalMeetings')} value={st.totalMeetings} />
        <KpiCard label="Today's Attendance (Present)" value={todaysAttendance} sub={`Date: ${today}`} />
      </div>

      {/* Daily Operations Shortcuts */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { tab: 'savings' as NavTabId, label: 'Record Saving' },
          { tab: 'loan_repayment' as NavTabId, label: 'Loan Repayment' },
          { tab: 'attendance' as NavTabId, label: 'Mark Attendance' },
          { tab: 'payment_verification' as NavTabId, label: 'Verify Payments' },
        ].map((q) => (
          <button
            key={q.tab}
            onClick={() => onNavigate(q.tab)}
            className="flex items-center justify-between gap-2 px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-[#087443] text-xs font-semibold text-[#142D4E] dark:text-white transition-colors"
          >
            <span className="truncate">{q.label}</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#087443] shrink-0" />
          </button>
        ))}
      </div>

      <DashboardCharts snapshot={snapshot} mode="secretary" />
    </div>
  );
};

// ==========================================
// MEMBER DASHBOARD OVERVIEW (100% PERSONAL ISOLATION)
// ==========================================
const MemberOverview: React.FC<{ onNavigate: (t: NavTabId) => void }> = ({ onNavigate }) => {
  const { session, snapshot, tr, isOnline } = useApp();
  if (!snapshot || !session) return null;

  const sym = snapshot.settings?.currencySymbol || '₹';
  const myId = session.user.memberId;
  const profile = snapshot.members.find((m) => m.memberId === myId) || session.memberProfile || null;

  const mySavings = snapshot.savings.filter((s) => s.memberId === myId);
  const myShares = snapshot.shares.filter((s) => s.memberId === myId);
  const myLoans = snapshot.loans.filter((l) => l.memberId === myId);
  const myPayments = snapshot.onlinePayments.filter((p) => p.memberId === myId);

  const curMonthPrefix = new Date().toISOString().slice(0, 7);
  const totalSavings = mySavings.reduce((acc, s) => acc + Number(s.totalSaving || 0), 0);
  const currentMonthSaving = mySavings
    .filter((s) => (s.date || '').startsWith(curMonthPrefix))
    .reduce((acc, s) => acc + Number(s.monthlySavingAmount || 0), 0);
  const totalSavingInterest = mySavings.reduce((acc, s) => acc + Number(s.interest || 0), 0);
  const totalSavingFine = mySavings.reduce((acc, s) => acc + Number(s.fine || 0), 0);

  const totalShares = myShares.reduce((acc, s) => acc + Number(s.numberOfShares || 0), 0);
  const totalShareValue = myShares.reduce((acc, s) => acc + Number(s.totalShareValue || 0), 0);

  const latestLoanByNum = useMemo(() => {
    const map: Record<string, (typeof myLoans)[number]> = {};
    for (const l of myLoans) {
      map[l.loanNumber || l.loanId] = l;
    }
    return Object.values(map);
  }, [myLoans]);

  const activeLoanBalance = latestLoanByNum
    .filter((l) => l.loanStatus === 'Active' || l.loanStatus === 'Running')
    .reduce((acc, l) => acc + Number(l.currentLoanBalance || 0), 0);
  const totalLoanRepaid = myLoans.reduce((acc, l) => acc + Number(l.loanRepayment || 0), 0);
  const totalLoanInterest = myLoans.reduce((acc, l) => acc + Number(l.interest || 0), 0);
  const totalLoanFine = myLoans.reduce((acc, l) => acc + Number(l.fine || 0), 0);
  const nextDue =
    latestLoanByNum
      .filter((l) => (l.loanStatus === 'Active' || l.loanStatus === 'Running') && l.nextDueDate)
      .map((l) => l.nextDueDate)
      .sort()[0] || 'No Active Due';

  const pendingPayments = myPayments.filter((p) => p.verificationStatus === 'Pending').length;

  const recentTransactions = useMemo(() => {
    const list: Array<{ id: string; date: string; type: string; amount: number; status: string }> = [
      ...mySavings.map((s) => ({
        id: s.savingId,
        date: s.date,
        type: 'Saving Entry',
        amount: s.totalSaving,
        status: s.paymentStatus,
      })),
      ...myLoans.map((l) => ({
        id: l.loanId,
        date: l.loanDate,
        type: l.isDisbursement ? 'Loan Disbursement' : 'Loan Repayment',
        amount: l.isDisbursement ? l.loanAmount : l.loanRepayment,
        status: l.paymentStatus,
      })),
      ...myPayments.map((p) => ({
        id: p.paymentId,
        date: p.date,
        type: `Online (${p.paymentMethod})`,
        amount: p.amount,
        status: p.verificationStatus,
      })),
    ];
    return list.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  }, [myLoans, myPayments, mySavings]);

  return (
    <div className="space-y-6">
      <LiveSyncHeaderBadge isLive={isOnline && snapshot.stats.isLive} syncedAt={snapshot.syncedAt} />

      {/* Member Identity Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          {profile?.photoUrl ? (
            <img
              src={profile.photoUrl}
              alt={profile.memberName}
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
            />
          ) : (
            <div className="w-16 h-16 rounded-xl bg-[#142D4E] text-white flex items-center justify-center text-xl font-bold">
              {(session.user.fullName || 'M').slice(0, 1).toUpperCase()}
            </div>
          )}
          <div>
            <h2 className="font-display text-lg font-bold text-[#142D4E] dark:text-white">
              {profile?.memberName || session.user.fullName}
            </h2>
            <p className="text-xs text-[#667085] dark:text-slate-400 font-mono-tabular mt-0.5">
              {myId || 'Member'} · {profile?.mobileNumber || session.user.mobileNumber}
            </p>
            <div className="mt-1.5">
              <StatusLabel status={profile?.accountStatus || session.user.accountStatus} />
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onNavigate('online_payments')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#087443] text-white text-xs font-semibold hover:bg-[#065c35]"
          >
            <QrCode className="w-4 h-4" />
            <span>Pay Online</span>
          </button>
          <button
            onClick={() => onNavigate('apply_loan')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <FileCheck2 className="w-4 h-4 text-[#087443]" />
            <span>{tr('nav_apply_loan')}</span>
          </button>
        </div>
      </div>

      {/* Personal Financial Summary KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        <KpiCard label="My Total Savings" value={formatCurrency(totalSavings, sym)} accent="text-[#087443] dark:text-emerald-400" />
        <KpiCard label="Current Month Saving" value={formatCurrency(currentMonthSaving, sym)} />
        <KpiCard label="Saving + Loan Interest" value={formatCurrency(totalSavingInterest + totalLoanInterest, sym)} />
        <KpiCard label="Total Fine Paid" value={formatCurrency(totalSavingFine + totalLoanFine, sym)} />
        <KpiCard label="My Total Shares" value={totalShares} />
        <KpiCard label="My Share Value" value={formatCurrency(totalShareValue, sym)} />
        <KpiCard label="Active Loan Balance" value={formatCurrency(activeLoanBalance, sym)} accent="text-amber-700 dark:text-amber-400" />
        <KpiCard label="Total Loan Repaid" value={formatCurrency(totalLoanRepaid, sym)} accent="text-emerald-700 dark:text-emerald-400" />
        <KpiCard label={tr('nextDueDate')} value={nextDue} />
        <KpiCard label="Pending Online Payments" value={pendingPayments} accent="text-amber-700 dark:text-amber-400" />
      </div>

      {/* Quick Member Links */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { tab: 'id_cards' as NavTabId, label: tr('nav_my_id_card'), icon: CreditCard },
          { tab: 'certificates' as NavTabId, label: tr('nav_my_certificate'), icon: Award },
          { tab: 'savings' as NavTabId, label: tr('nav_my_savings'), icon: PiggyBank },
          { tab: 'loans' as NavTabId, label: tr('nav_my_loan'), icon: Landmark },
        ].map((q) => {
          const Icon = q.icon;
          return (
            <button
              key={q.tab}
              onClick={() => onNavigate(q.tab)}
              className="flex items-center gap-2.5 px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-[#087443] text-xs font-semibold text-[#142D4E] dark:text-white transition-colors"
            >
              <Icon className="w-4 h-4 text-[#087443] shrink-0" />
              <span className="truncate">{q.label}</span>
            </button>
          );
        })}
      </div>

      {/* Recent Personal Transactions */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
        <h3 className="text-sm font-bold text-[#142D4E] dark:text-white mb-4">Recent Personal Transactions</h3>
        {recentTransactions.length === 0 ? (
          <p className="text-xs text-[#667085] dark:text-slate-400 py-4">No personal transactions recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-2 pr-3">Reference</th>
                  <th className="py-2 px-3">Date</th>
                  <th className="py-2 px-3">Type</th>
                  <th className="py-2 px-3 text-right">Amount</th>
                  <th className="py-2 pl-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {recentTransactions.map((tx) => (
                  <tr key={tx.id}>
                    <td className="py-2.5 pr-3 font-mono-tabular font-medium">{tx.id}</td>
                    <td className="py-2.5 px-3 font-mono-tabular">{tx.date}</td>
                    <td className="py-2.5 px-3">{tx.type}</td>
                    <td className="py-2.5 px-3 text-right font-mono-tabular font-semibold">{formatCurrency(tx.amount, sym)}</td>
                    <td className="py-2.5 pl-3">
                      <StatusLabel status={tx.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

// ==========================================
// OFFICER PROFILE VIEW (President / Secretary)
// ==========================================
const OfficerProfileView: React.FC = () => {
  const { session } = useApp();
  if (!session) return null;
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 max-w-xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-[#142D4E] text-white flex items-center justify-center">
            <BadgeCheck className="w-6 h-6 text-[#D5A642]" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-[#142D4E] dark:text-white">{session.user.fullName}</h2>
            <p className="text-xs text-[#667085] dark:text-slate-400">
              {session.user.role} · {session.user.userId}
            </p>
          </div>
        </div>
        <dl className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs border-t border-slate-100 dark:border-slate-800 pt-4">
          <div>
            <dt className="text-slate-500">Registered Mobile</dt>
            <dd className="font-mono-tabular font-semibold mt-0.5">{session.user.mobileNumber}</dd>
          </div>
          <div>
            <dt className="text-slate-500">Account Status</dt>
            <dd className="mt-0.5"><StatusLabel status={session.user.accountStatus} /></dd>
          </div>
          {session.user.email && (
            <div>
              <dt className="text-slate-500">Email</dt>
              <dd className="font-medium mt-0.5">{session.user.email}</dd>
            </div>
          )}
          <div>
            <dt className="text-slate-500">Last Login</dt>
            <dd className="font-mono-tabular mt-0.5">
              {session.user.lastLoginAt ? new Date(session.user.lastLoginAt).toLocaleString() : 'Active Session'}
            </dd>
          </div>
        </dl>
      </div>
      <SecurityAndCredentialsView />
    </div>
  );
};

// ==========================================
// MAIN ROLE DASHBOARD ROUTER
// ==========================================
export const RoleDashboards: React.FC = () => {
  const { session, snapshot } = useApp();
  const [activeTab, setActiveTab] = useState<NavTabId>('dashboard');

  if (!session) return null;
  const role = session.user.role;
  const isMember = role === 'Member';

  const renderContent = () => {
    if (!snapshot) {
      return (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center text-sm text-slate-500">
          Loading authorized society workspace...
        </div>
      );
    }

    switch (activeTab) {
      case 'dashboard':
        if (role === 'System') return <SystemOverview onNavigate={setActiveTab} />;
        if (role === 'President') return <PresidentOverview onNavigate={setActiveTab} />;
        if (role === 'Secretary') return <SecretaryOverview onNavigate={setActiveTab} />;
        return <MemberOverview onNavigate={setActiveTab} />;

      case 'members':
        return <MemberRegisterView readOnlyOwn={isMember} />;
      case 'my_profile':
        return isMember ? (
          <div className="space-y-6">
            <MemberRegisterView readOnlyOwn />
            <SecurityAndCredentialsView />
          </div>
        ) : (
          <OfficerProfileView />
        );

      case 'member_pin':
        return role === 'System' ? <UsersAndPinManagerView focus="members" /> : null;
      case 'president_mgr':
        return role === 'System' ? <UsersAndPinManagerView focus="President" /> : null;
      case 'secretary_mgr':
        return role === 'System' ? <UsersAndPinManagerView focus="Secretary" /> : null;

      case 'savings':
        return <SavingRegisterView readOnlyOwn={isMember} />;
      case 'shares':
        return <ShareRegisterView readOnlyOwn={isMember} />;
      case 'loans':
        return <LoanRegisterView readOnlyOwn={isMember} />;
      case 'loan_repayment':
        return <LoanRegisterView readOnlyOwn={isMember} defaultRepayMode />;
      case 'cashbook':
        return isMember ? null : <CashBookView />;

      case 'meetings':
        return isMember ? null : <MeetingsView />;
      case 'attendance':
        return <AttendanceRegisterView readOnlyOwn={isMember} />;

      case 'loan_applications':
      case 'apply_loan':
        return <LoanApplicationView approvalMode={false} />;
      case 'loan_approval':
        return role === 'System' || role === 'President' ? <LoanApplicationView approvalMode /> : null;

      case 'online_payments':
      case 'payment_history':
        return <OnlinePaymentView verificationDesk={false} />;
      case 'payment_verification':
        return role === 'System' || role === 'Secretary' ? <OnlinePaymentView verificationDesk /> : null;

      case 'id_certificates':
        return <IdAndCertificateHub onlyOwn={isMember} defaultTab="id" />;
      case 'id_cards':
        return <IdAndCertificateHub onlyOwn={isMember} defaultTab="id" />;
      case 'certificates':
        return <IdAndCertificateHub onlyOwn={isMember} defaultTab="cert" />;

      case 'notices':
        return <NoticeBoardView />;
      case 'notifications':
        return <NotificationsCenterView />;
      case 'reports':
        return <ReportsCenterView />;

      case 'media_manager':
        return role === 'System' ? <SocietySettingsView section="media" /> : null;
      case 'theme_manager':
        return role === 'System' ? <SocietySettingsView section="theme" /> : null;
      case 'society_settings':
        return role === 'System' ? <SocietySettingsView section="settings" /> : null;
      case 'content_manager':
        return role === 'System' ? <SocietySettingsView section="content" /> : null;

      case 'permissions':
        return role === 'System' ? <PermissionSwitchboardView /> : null;
      case 'google_sheets':
        return role === 'System' ? <GoogleSheetsIntegrationView /> : null;
      case 'backup_restore':
        return role === 'System' ? <BackupAndRestoreView /> : null;
      case 'offline_sync':
        return <OfflineSyncAndConflictView />;
      case 'audit_log':
        return role === 'System' ? <AuditLogView /> : null;
      case 'security':
        return role === 'System' ? <SecurityAndCredentialsView /> : null;

      default:
        return null;
    }
  };

  return (
    <AppShell activeTab={activeTab} onSelectTab={setActiveTab}>
      {session.user.mustChangePassword && activeTab !== 'security' && activeTab !== 'my_profile' && (
        <div className="mb-6 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs sm:text-sm text-red-800 dark:text-red-200">
            <ShieldAlert className="w-5 h-5 text-red-600 shrink-0" />
            <div>
              <p className="font-bold">Security Action Required: Update Your Temporary Credentials</p>
              <p className="text-xs opacity-90">
                Please change your initial password or PIN before continuing society administration.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab(role === 'System' ? 'security' : 'my_profile')}
            className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold whitespace-nowrap"
          >
            Update Credentials Now
          </button>
        </div>
      )}
      {renderContent()}
    </AppShell>
  );
};
